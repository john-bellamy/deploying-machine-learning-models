def _is_prime(n):
    
    if n <= 1: 
        return False
    
    if n <= 3: 
        return True
    
    if n%2 == 0 or n%3 == 0: 
        return False
    
    n_root = int(n**0.5)
    
    f = 5
    
    while f <= n_root:
        
        if n%f == 0 or n%(f + 2) == 0: 
            
            return False
        
        f+= 6
    
    return True


def _prime_sieve(n):
    
    sieve = [True] * int(n//2)
    
    for i in range(3, int(n**0.5)+1, 2):
        
        if sieve[i//2]:
            
            sieve[i*i//2::i] = [False] * (int((n-i*i-1)//(2*i))+1)
            
    return [2] + [2*i+1 for i in range(1,int(n//2)) if sieve[i]]


def get_max_prime(m):

    prime_sum = [0]

    for p in _prime_sieve(m):
    
        prime_sum.append(prime_sum[-1] + p)
        
        if prime_sum[-1] >= m: 
            
            break

    c = len(prime_sum)

    terms = 1
    
    for i in range(c):
        
        for j in range(c-1, i+terms, -1):
            
            n = prime_sum[j] - prime_sum[i]
            
            if (j-i > terms and _is_prime(n)):
                
                terms, max_prime = j-i, n
                
    return max_prime
