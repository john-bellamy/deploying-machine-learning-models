import sys
from prime_operations.prime_operations import get_max_prime

if len(sys.argv) < 2:
    
    print("Sum of most the longest consecutive primes < {1} is {0}"
    .format(get_max_prime(1000000), 1000000))  

else:

    try:
        print("Sum of most the longest consecutive primes < {1} is {0}"
        .format(get_max_prime(int(sys.argv[1])), sys.argv[1]))
    except:
        print("Something went wrong...\nMake sure you pass one and only one argument which must be an integer.\nFor default of one million pass zero arguments.")
